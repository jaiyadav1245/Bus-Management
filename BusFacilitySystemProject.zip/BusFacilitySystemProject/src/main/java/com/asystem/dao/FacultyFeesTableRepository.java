package com.asystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asystem.entities.FacultyFeesTable;

public interface FacultyFeesTableRepository extends JpaRepository<FacultyFeesTable, Integer>{

}
