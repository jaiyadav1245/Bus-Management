package com.asystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.asystem.entities.StudentFeesTable;

public interface StudentFeesTableRepository extends JpaRepository<StudentFeesTable, Integer>{

}
