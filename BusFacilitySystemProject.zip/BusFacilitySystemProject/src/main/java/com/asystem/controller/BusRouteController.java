package com.asystem.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BusRouteController {

}
