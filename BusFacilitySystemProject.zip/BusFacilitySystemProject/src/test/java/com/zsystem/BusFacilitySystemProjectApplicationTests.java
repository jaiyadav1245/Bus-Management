package com.zsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusFacilitySystemProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
